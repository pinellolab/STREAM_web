from setuptools import setup

exec (open('upload_button/version.py').read())

setup(
    name='upload_button',
    version=__version__,
    author='lucapinello',
    packages=['upload_button'],
    include_package_data=True,
    license='MIT',
    description='upload button',
    install_requires=[]
)
