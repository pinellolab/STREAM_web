/* eslint no-console: 0*/

import $ from 'jquery'
import React, {Component} from 'react';
import PropTypes from 'prop-types';

/**
 * FilesUpload is an example component.
 * It takes a list of `label`, and
 * displays buttons to upload files
 */



export default class FilesUpload extends Component {


  constructor() {
    super()
    this.handleSubmit = this.handleSubmit.bind(this)
  }

  handleSubmit(e) {
      e.preventDefault()
      console.log('toko');
      var form_data = new FormData($('#upload-file')[0]);

      $('#upload-file-btn').prop('disabled',true);

      $.ajax({
            type: 'POST',
            url: '/uploadajax',
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            async: false,
            success: function(data) {
              console.log(data);
            }
        });
      // do something with the file
      $('#upload-file-btn').prop('disabled',false);

    }

    render() {

        const {label} = this.props;

        const fileLabels=this.props.label.split(',').map((name, index) =>

          <div key={index} >
          <label  for={'file_'+index}> {name}</label>
          <input  name={name} type="file" />
          </div>
        );

        return (


          <form id="upload-file"
          method="post"
          enctype="multipart/form-data">
          { fileLabels }
          <button id="upload-file-btn" type="button"
          onClick={this.handleSubmit}> Upload</button>
          </form>




        );
    }
}

FilesUpload.propTypes = {
    /**
     * The ID used to identify this compnent in Dash callbacks
     */
    id: PropTypes.string,

    /**
     * A label that will be printed when this component is rendered.
     */
    label: PropTypes.string.isRequired,

    /**
     * Dash-assigned callback that should be called whenever any of the
     * properties change
     */
    setProps: PropTypes.func
};
