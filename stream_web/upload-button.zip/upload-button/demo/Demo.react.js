import React, {Component} from 'react';
import {FilesUpload} from '../src';

class Demo extends Component {
    constructor() {
        super();
        this.state = {
            value: ''
        }
    }

    render() {
        return (
            <div>
                <h1>upload-button Demo</h1>

                <hr/>
                <h2>ExampleComponent</h2>
                <FilesUpload
                    label="This is an example label"

                />
                <hr/>
            </div>
        );
    }
}

export default Demo;
