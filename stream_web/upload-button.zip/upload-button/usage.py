# -*- coding: utf-8 -*-
import os
import dash
import dash_core_components as dcc
import dash_html_components as html
from upload_button import FilesUpload, upload_files


app = dash.Dash(csrf_protect=False )
app.server.config['UPLOAD_FOLDER']='./'
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True


label_files=['Load Fastq1 rep1','Load Fastq1 rep2','Load Fastq1 rep3']
label_files2=['Load Fastq2 rep1','Load Fastq2 rep2','Load Fastq2 rep3']

upload_url1='/uploadajax1'
upload_url2='/uploadajax2'

@app.server.route(upload_url1, methods = ['POST'])
def save_files1():
    return upload_files(label_files,app.server.config['UPLOAD_FOLDER'])

@app.server.route(upload_url2, methods = ['POST'])
def save_files2():
    return upload_files(label_files2,app.server.config['UPLOAD_FOLDER'])

app.layout = html.Div(children=[
    html.H1(children='Dash Upload Demo'),

    FilesUpload(
        id='form_fastq1',
        label=','.join(label_files),
        uploadUrl=upload_url1,
    ),

    FilesUpload(
            id='form_fastq2',
            label=','.join(label_files2),
            uploadUrl=upload_url2,
        ),


])

if __name__ == '__main__':
    app.run_server(debug=True)
