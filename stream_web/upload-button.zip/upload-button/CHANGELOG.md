# Change Log for upload-button
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## Unreleased

### Added
- Feature x

### Fixed
- Bug y

## 0.0.1 - 2017-09-03
- Initial release

[Unreleased]: https://github.com/lucapinello/upload-button/v0.0.1...HEAD
